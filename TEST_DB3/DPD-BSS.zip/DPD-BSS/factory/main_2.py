from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
from abc import ABC, abstractmethod
from typing import Optional

test = GraphvizOutput()
test.output_file = "main_2.json"
test.output_type = 'json'

# Abstract base class for enemy ships
class NavioInimigo(ABC):
    @abstractmethod
    def exibir_navio_inimigo_na_tela(self):
        pass

    @abstractmethod
    def seguir_navio_do_heroi(self):
        pass

    @abstractmethod
    def atirar(self):
        pass

# Concrete implementation for Rocket enemy ship
class NavioInimigoFoguete(NavioInimigo):
    def exibir_navio_inimigo_na_tela(self):
        print("Exibindo navio inimigo foguete na tela")

    def seguir_navio_do_heroi(self):
        print("Navio foguete seguindo o herói")

    def atirar(self):
        print("Navio foguete atirando")

# Concrete implementation for UFO enemy ship
class NavioInimigoUFO(NavioInimigo):
    def exibir_navio_inimigo_na_tela(self):
        print("Exibindo OVNI inimigo na tela")

    def seguir_navio_do_heroi(self):
        print("OVNI seguindo o herói")

    def atirar(self):
        print("OVNI atirando")

# Factory class for creating enemy ships
class FabricaDeNavios:
    def __init__(self, tipo: str):
        self.tipo = tipo

    def retornar_navio_fabricado(self) -> Optional[NavioInimigo]:
        if self.tipo == "U":
            return NavioInimigoUFO()
        elif self.tipo == "R":
            return NavioInimigoFoguete()
        else:
            return None

def ataque_inimigo(navio: Optional[NavioInimigo]):
    if navio:
        navio.exibir_navio_inimigo_na_tela()
        navio.seguir_navio_do_heroi()
        navio.atirar()
    else:
        print("Digite U ou R ou B na próxima vez ;)")

if __name__ == "__main__":
    with PyCallGraph(output=test):
        tipo_navio_inimigo = input(
            "Qual tipo de navio inimigo você quer criar? (digite U / R / B) -> "
        ).upper()
        fabrica = FabricaDeNavios(tipo_navio_inimigo)
    
        ataque_inimigo(fabrica.retornar_navio_fabricado())