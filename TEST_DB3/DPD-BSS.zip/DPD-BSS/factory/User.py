from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "User.json"
test.output_type = 'json'

from abc import ABC, abstractmethod

class Animal(ABC):
    @abstractmethod
    def make_sound(self):
        pass

class Cat(Animal):
    def make_sound(self):
        return "Meow"

class Dog(Animal):
    def make_sound(self):
        return "Woof"

class Factory:
    def create_animal(self, animal_type):
        if animal_type.lower() == 'cat':
            return Cat()
        elif animal_type.lower() == 'dog':
            return Dog()
        else:
            raise ValueError(f"Invalid animal type: {animal_type}")

    def make_sound(self, animal_type):
        animal = self.create_animal(animal_type)
        return animal.make_sound()

if __name__ == '__main__':
    with PyCallGraph(output=test):
        animal = 'Cat'
        factory = Factory()
        sound = factory.make_sound(animal)
        print(f"The {animal} says: {sound}")