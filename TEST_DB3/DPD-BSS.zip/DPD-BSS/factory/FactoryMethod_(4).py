from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "FactoryMethod_(4).json"
test.output_type = 'json'

from abc import ABC, abstractmethod


class ProductFactory(ABC):
    @abstractmethod
    def operation(self) -> str:
        pass


class ProductOne(ProductFactory):
    def operation(self) -> str:
        return "ProductOne created"


class ProductTwo(ProductFactory):
    def operation(self) -> str:
        return "ProductTwo created"


class CreatorFactory(ABC):
    @abstractmethod
    def factory_method(self):
        pass

    def create_product(self):
        product = self.factory_method()

        return product


class CreatorOne(CreatorFactory):
    def factory_method(self):
        return ProductOne()


class CreatorTwo(CreatorFactory):
    def factory_method(self):
        return ProductTwo()


def some_code_to_create_product(creator: CreatorFactory) -> None:
    product = creator.create_product()
    print(product)
    print(product.operation())


if __name__ == "__main__":
    with PyCallGraph(output=test):
        some_code_to_create_product(CreatorOne())
        some_code_to_create_product(CreatorTwo())