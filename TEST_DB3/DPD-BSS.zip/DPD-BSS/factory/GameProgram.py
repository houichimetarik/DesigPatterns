from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
from abc import ABC, abstractmethod

test = GraphvizOutput()
test.output_file = "GameProgram.json"
test.output_type = 'json'

class Game:
    def __init__(self, name):
        self.name = name

    def __str__(self):
        return f"This is a {self.name} game."

class GameCreator(ABC):
    @abstractmethod
    def create(self) -> Game:
        pass

class ValorantGame(Game):
    def __init__(self):
        super().__init__("Valorant")

class ValorantGameCreator(GameCreator):
    def create(self) -> Game:
        return ValorantGame()

class MonopolyGame(Game):
    def __init__(self):
        super().__init__("Monopoly")

class MonopolyGameCreator(GameCreator):
    def create(self) -> Game:
        return MonopolyGame()

def main():
    game_type = input('Enter the type of game [PC, Board]: ')
    game_factory = None
    if game_type == 'PC':
        game_factory = ValorantGameCreator()
    elif game_type == 'Board':
        game_factory = MonopolyGameCreator()

    if game_factory:
        game = game_factory.create()
        print(game)

if __name__ == '__main__':
    with PyCallGraph(output=test):
        main()