from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
from abc import ABC, abstractmethod
from random import choice

test = GraphvizOutput()
test.output_file = "factory.json"
test.output_type = 'json'

"""
    Creational :
        Factory
"""

class PlayerBase(ABC):
    choices = ['r', 'p', 's']

    @abstractmethod
    def move(self):
        pass

class HumanPlayer(PlayerBase):
    def move(self):
        while True:
            mov = input("Choose your next move (r/p/s): ").lower()
            if mov in self.choices:
                return mov
            print("Invalid move. Please choose 'r', 'p', or 's'.")

class SystemPlayer(PlayerBase):
    def move(self):
        return choice(self.choices)

class PlayerFactory:
    @staticmethod
    def create_player(player_type: str) -> PlayerBase:
        if player_type == 'human':
            return HumanPlayer()
        elif player_type == 'system':
            return SystemPlayer()
        else:
            raise ValueError(f"Invalid player type: {player_type}")

class Game:
    @staticmethod
    def start_game():
        while True:
            game_type = input("Please choose game type (s -> single player, m -> multiplayer): ").lower()
            if game_type == 's':
                p1 = PlayerFactory.create_player('human')
                p2 = PlayerFactory.create_player('system')
                return p1, p2
            elif game_type == 'm':
                p1 = PlayerFactory.create_player('human')
                p2 = PlayerFactory.create_player('human')
                return p1, p2
            else:
                print("Invalid input. Please enter 's' or 'm'.")

if __name__ == '__main__':
    with PyCallGraph(output=test):
        player1, player2 = Game.start_game()
    
        print("Player 1's move:")
        player1.move()
        print("Player 2's move:")
        player2.move()