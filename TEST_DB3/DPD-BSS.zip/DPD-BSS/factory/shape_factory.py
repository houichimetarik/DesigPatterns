from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "shape_factory.json"
test.output_type = 'json'

# Define the Shape base class
class Shape:
    def draw(self):
        pass

# Define the Circle class
class Circle(Shape):
    def draw(self):
        print("Drawing a circle")

# Define the Triangle class
class Triangle(Shape):
    def draw(self):
        print("Drawing a triangle")

class ShapeFactory:
    @staticmethod
    def get_shape(shape: str) -> Shape:
        match shape:
            case "Circle":
                return Circle()
            case "Triangle":
                return Triangle()
            case other:
                raise ValueError("No shape found")

if __name__ == "__main__":
    with PyCallGraph(output=test):
        shape = ShapeFactory.get_shape("Circle")
        shape.draw()