from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "circle.json"
test.output_type = 'json'

# shape.py
from abc import ABC, abstractmethod

class Shape(ABC):
    @abstractmethod
    def draw(self):
        pass

    @abstractmethod
    def area(self):
        pass

class Circle(Shape):
    def __init__(self, r=7) -> None:
        super().__init__()
        self.r = r

    def draw(self):
        return "Drawing a Circle"

    def area(self):
        return 3.14 * self.r * self.r


if __name__ == "__main__":
    with PyCallGraph(output=test):
        c = Circle(7)
        print(c.draw())
        print(c.area())