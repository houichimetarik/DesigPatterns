from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
import sys
import io

test = GraphvizOutput()
test.output_file = "factory_method_(5).json"
test.output_type = 'json'

class GreekGetter:
    def __init__(self):
        self.trans = dict(dog="σκύλος", cat="γάτα")

    def get(self, msgid):
        return self.trans.get(msgid, str(msgid))

class EnglishGetter:
    def get(self, msgid):
        return str(msgid)

def get_localizer(language="English"):
    languages = dict(English=EnglishGetter, Greek=GreekGetter)
    return languages[language]()

def safe_print(*args, **kwargs):
    try:
        print(*args, **kwargs)
    except UnicodeEncodeError:
        buf = io.StringIO()
        for arg in args:
            buf.write(str(arg) + ' ')
        output = buf.getvalue()
        buf.close()
        print(output.encode('ascii', errors='replace').decode('ascii'), **kwargs)

if __name__ == '__main__':
    # Try to set console output encoding to UTF-8
    if sys.stdout.encoding != 'utf-8':
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')

    with PyCallGraph(output=test):
        e, g = get_localizer(language="English"), get_localizer(language="Greek")
        for msgid in "dog parrot cat bear".split():
            safe_print(e.get(msgid), g.get(msgid))

# Expected OUTPUT:
# dog σκύλος
# parrot parrot
# cat γάτα
# bear bear