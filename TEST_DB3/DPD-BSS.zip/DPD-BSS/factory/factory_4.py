from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
import json
import xml.etree.ElementTree as etree
import os

test = GraphvizOutput()
test.output_file = "factory_4.json"
test.output_type = 'png'

class JSONDataExtractor:
    def __init__(self, filepath):
        self.data = dict()
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"The file {filepath} does not exist.")
        with open(filepath, mode='r', encoding='utf-8') as f:
            self.data = json.load(f)
    
    @property
    def parsed_data(self):
        return self.data

class XMLDataExtractor:
    def __init__(self, filepath):
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"The file {filepath} does not exist.")
        self.tree = etree.parse(filepath)

    @property
    def parsed_data(self):
        return self.tree

def data_extraction_factory(filepath):
    if filepath.endswith('json'):
        extractor = JSONDataExtractor
    elif filepath.endswith('xml'):
        extractor = XMLDataExtractor
    else:
        raise ValueError(f'Cannot extract data from {filepath}')
    return extractor(filepath)

def extract_data_from(filepath):
    try:
        factory_obj = data_extraction_factory(filepath)
    except (ValueError, FileNotFoundError) as e:
        print(f"Error: {e}")
        return None
    return factory_obj

if __name__ == "__main__":
    with PyCallGraph(output=test):
        json_filepath = "./movies.json"
        xml_filepath = "./person.xml"

        print(f"Current working directory: {os.getcwd()}")
        print(f"Attempting to extract data from JSON file: {json_filepath}")
        json_data = extract_data_from(json_filepath)
        if json_data:
            print("JSON data extracted successfully:")
            print(json_data.parsed_data)
        else:
            print("Failed to extract JSON data.")
        
        print(f"\nAttempting to extract data from XML file: {xml_filepath}")
        xml_tree = extract_data_from(xml_filepath)
        if xml_tree:
            print("XML data extracted successfully:")
            print(xml_tree.parsed_data)
        else:
            print("Failed to extract XML data.")