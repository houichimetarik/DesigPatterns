from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
from enum import Enum
from abc import ABC, abstractmethod

test = GraphvizOutput()
test.output_file = "client.json"
test.output_type = 'json'

class Chair(ABC):
    @abstractmethod
    def get_dimension(self) -> str:
        pass

class SmallChair(Chair):
    def get_dimension(self) -> str:
        return "Small chair"

class MediumChair(Chair):
    def get_dimension(self) -> str:
        return "Medium chair"

class BigChair(Chair):
    def get_dimension(self) -> str:
        return "Big chair"

class ChairType(Enum):
    SMALL = 1
    MEDIUM = 2
    BIG = 3

class ChairFactory:
    @staticmethod
    def get_chair(chair_type: ChairType) -> Chair:
        if chair_type == ChairType.SMALL:
            return SmallChair()
        elif chair_type == ChairType.MEDIUM:
            return MediumChair()
        elif chair_type == ChairType.BIG:
            return BigChair()
        else:
            raise ValueError(f"Invalid chair type: {chair_type}")

if __name__ == '__main__':
    with PyCallGraph(output=test):
        chair: Chair = ChairFactory.get_chair(ChairType.BIG)
        print(chair.get_dimension())