from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
from abc import ABC, abstractmethod

test = GraphvizOutput()
test.output_file = "PizzaTestDrive_1.json"
test.output_type = 'json'

# Abstract Pizza class
class Pizza(ABC):
    def __init__(self):
        self.name = ""
        self.dough = ""
        self.sauce = ""
        self.toppings = []

    def prepare(self):
        print(f"Preparing {self.name}")
        print("Tossing dough...")
        print("Adding sauce...")
        print("Adding toppings: ")
        for topping in self.toppings:
            print(f"  {topping}")

    def bake(self):
        print("Bake for 25 minutes at 350")

    def cut(self):
        print("Cutting the pizza into diagonal slices")

    def box(self):
        print("Place pizza in official PizzaStore box")

    def get_name(self):
        return self.name

# Abstract PizzaStore class
class PizzaStore(ABC):
    @abstractmethod
    def create_pizza(self, item: str) -> Pizza:
        pass

    def order_pizza(self, type: str) -> Pizza:
        pizza = self.create_pizza(type)
        print(f"--- Making a {pizza.get_name()} ---")
        pizza.prepare()
        pizza.bake()
        pizza.cut()
        pizza.box()
        return pizza

# NY Style Pizza classes
class NYStyleCheesePizza(Pizza):
    def __init__(self):
        super().__init__()
        self.name = "NY Style Sauce and Cheese Pizza"
        self.dough = "Thin Crust Dough"
        self.sauce = "Marinara Sauce"
        self.toppings.append("Grated Reggiano Cheese")

class NYStylePizzaStore(PizzaStore):
    def create_pizza(self, item: str) -> Pizza:
        if item == "cheese":
            return NYStyleCheesePizza()
        # Add other pizza types here if needed
        else:
            return None

# Chicago Style Pizza classes
class ChicagoStyleCheesePizza(Pizza):
    def __init__(self):
        super().__init__()
        self.name = "Chicago Style Deep Dish Cheese Pizza"
        self.dough = "Extra Thick Crust Dough"
        self.sauce = "Plum Tomato Sauce"
        self.toppings.append("Shredded Mozzarella Cheese")

    def cut(self):
        print("Cutting the pizza into square slices")

class ChicagoStylePizzaStore(PizzaStore):
    def create_pizza(self, item: str) -> Pizza:
        if item == "cheese":
            return ChicagoStyleCheesePizza()
        # Add other pizza types here if needed
        else:
            return None

if __name__ == '__main__':
    with PyCallGraph(output=test):
        nyStore = NYStylePizzaStore()
        chicagoStore = ChicagoStylePizzaStore()
    
        pizza = nyStore.order_pizza('cheese')
        print('Ethan ordered a', pizza.get_name())
        print('')
    
        pizza = chicagoStore.order_pizza('cheese')
        print('Joel ordered a', pizza.get_name())