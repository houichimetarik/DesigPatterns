from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
import json
import requests
import time

test = GraphvizOutput()
test.output_file = "FactoryExmpl.json"
test.output_type = 'json'

class Currency:
    def __init__(self, name):
        self.name = name
        self.rates = []

    def add_rate(self, rate):
        self.rates.append(rate)

    def ls(self):
        print(f"{self.name}: {self.rates}")

class TRY(Currency):
    def __init__(self):
        super().__init__("TRY")

class USD(Currency):
    def __init__(self):
        super().__init__("USD")

class RUB(Currency):
    def __init__(self):
        super().__init__("RUB")

class INR(Currency):
    def __init__(self):
        super().__init__("INR")

class Factory:
    def __init__(self):
        self.currencies = {
            "TRY": TRY(),
            "USD": USD(),
            "RUB": RUB(),
            "INR": INR()
        }

    def get_exchange(self, currency, rate):
        if currency in self.currencies:
            self.currencies[currency].add_rate(rate)
            return self.currencies[currency]
        return None

def main(urlAPI):
    resp = requests.get(urlAPI)
    if resp.ok:
        try:
            jsonData = resp.json()
            if 'rates' not in jsonData:
                print("Error: 'rates' key not found in API response")
                print("API response:", json.dumps(jsonData, indent=2))
                return

            parsedData = jsonData['rates']
            factory = Factory()

            for currency, rate in parsedData.items():
                factory.get_exchange(currency, rate)

            for currency in factory.currencies.values():
                currency.ls()
        except json.JSONDecodeError:
            print("Error: Unable to parse JSON response")
            print("Response content:", resp.text)
    else:
        print(f"Error: HTTP request failed with status code {resp.status_code}")
        print("Response content:", resp.text)

if __name__ == '__main__':
    with PyCallGraph(output=test):
        for i in range(3):
            main("https://api.exchangeratesapi.io/latest")
            time.sleep(1)  # Add a small delay between requests