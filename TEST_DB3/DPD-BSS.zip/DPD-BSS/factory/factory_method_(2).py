from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "factory_method_(2).json"
test.output_type = 'json'

"""Factory Method pattern
"""


class _Car(object):
    pass


class _Bike(object):
    pass


def factory_method(product_type):
    if product_type == "car":
        return _Car()

    elif product_type == "bike":
        return _Bike()

    else:
        raise ValueError("Cannot make: {}".format(product_type))


def main():
    for product_type in ("car", "bike"):
        product = factory_method(product_type)
        print(str(product))


if __name__ == "__main__":
    with PyCallGraph(output=test):
        main()