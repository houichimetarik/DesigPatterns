from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
from abc import ABC, abstractmethod
from typing import List

test = GraphvizOutput()
test.output_file = "main_4.json"
test.output_type = 'json'

# Abstract Product
class Product(ABC):
    @abstractmethod
    def operation(self, data: List[int]) -> None:
        pass

    @abstractmethod
    def get_result(self) -> int:
        pass

# Concrete Products
class ConcreteProduct1(Product):
    def operation(self, data: List[int]) -> None:
        self.result = sum(data)

    def get_result(self) -> int:
        return self.result

class ConcreteProduct2(Product):
    def operation(self, data: List[int]) -> None:
        self.result = max(data)

    def get_result(self) -> int:
        return self.result

class ConcreteProduct3(Product):
    def operation(self, data: List[int]) -> None:
        self.result = min(data)

    def get_result(self) -> int:
        return self.result

# Product Factory
class ProductFactory:
    @staticmethod
    def some_operation(creator: str, data: List[int]) -> Product:
        if creator == "1":
            product = ConcreteProduct1()
        elif creator == "2":
            product = ConcreteProduct2()
        elif creator == "3":
            product = ConcreteProduct3()
        else:
            raise ValueError("Invalid creator type")
        
        product.operation(data)
        return product

def hello(name):
    return "Happy testing! " + name

if __name__ == "__main__":
    with PyCallGraph(output=test):
        input_data = [2, 2, 7, 4, 3, 5, 8]
    
        print("App: Launched with the ConcreteCreator1.")
        product1 = ProductFactory.some_operation("1", input_data)
        print(f"App: ConcreteProduct1 result is indeed {product1.get_result()}")
        print("\n")
    
        print("App: Launched with the ConcreteCreator2.")
        product2 = ProductFactory.some_operation("2", input_data)
        print(f"App: ConcreteProduct2 result is indeed {product2.get_result()}")
        print("\n")
    
        print("App: Launched with the ConcreteCreator3.")
        product3 = ProductFactory.some_operation("3", input_data)
        print(f"App: ConcreteProduct3 result is indeed {product3.get_result()}")
        print("\n")