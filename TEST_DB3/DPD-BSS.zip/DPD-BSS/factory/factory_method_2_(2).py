from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "factory_method_2_(2).json"
test.output_type = 'json'


import sys
import io



# -*- coding: utf-8 -*-

#!/usr/bin/env python


"""
Factory Method Pattern Example

This code demonstrates the Factory Method pattern by implementing
a localization system for English and Greek languages.
"""

class GreekLocalizer:
    """A localizer for Greek language"""

    def __init__(self):
        self.translations = {"dog": "σκύλος", "cat": "γάτα"}

    def localize(self, message):
        """Localize the given message to Greek"""
        return self.translations.get(message, str(message))


class EnglishLocalizer:
    """A localizer for English language"""

    def localize(self, message):
        """Simply return the original message for English"""
        return str(message)


def create_localizer(language="English"):
    """Factory method to create a localizer based on the language"""
    localizers = {
        "English": EnglishLocalizer,
        "Greek": GreekLocalizer
    }
    return localizers[language]()


if __name__ == '__main__':
    # Redirect stdout to a StringIO object
    output = io.StringIO()
    sys.stdout = output

    with PyCallGraph(output=test):
        # Create our localizers
        english_localizer = create_localizer(language="English")
        greek_localizer = create_localizer(language="Greek")
        
        # Localize some text
        for word in "dog parrot cat bear".split():
            print(english_localizer.localize(word), greek_localizer.localize(word))
    
    # Reset stdout
    sys.stdout = sys.__stdout__

    # Print the captured output
    print(output.getvalue())

### OUTPUT ###
# dog σκύλος
# parrot parrot
# cat γάτα
# bear bear