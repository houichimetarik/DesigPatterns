from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
from abc import ABCMeta, abstractmethod

test = GraphvizOutput()
test.output_file = "factory_3.json"
test.output_type = 'json'

class Pizza(metaclass=ABCMeta):
    def __init__(self):
        self.name = None
        self.dough = None
        self.sauce = None
        self.toppings = []
     
    def prepare(self):
        print(f"Preparing {self.name}")
        print("Tossing dough...")
        print("Adding sauce...")
        print("Adding toppings:")
        for topping in self.toppings:
            print(f"    {topping}")
            
    def bake(self): 
        print("Bake for 25 minutes at 350")
        
    def cut(self):
        print("Cutting the pizza into diagonal slices")
        
    def box(self):
        print("Place pizza in official PizzaStore box")
        
    def getName(self):
        return self.name
    
class NYCheesePizza(Pizza):
    def __init__(self):
        super().__init__()
        self.name = "NY Style Sauce and Cheese Pizza"
        self.dough = "Thin Crust Dough"
        self.sauce = "Marinara Sauce"
        self.toppings.append("Grated Reggiano Cheese")
        
class NYPepperoniPizza(Pizza):
    def __init__(self):
        super().__init__()
        self.name = "NY Style Sauce and Pepperoni Pizza"
        self.dough = "Thin Crust Dough"
        self.sauce = "Marinara Sauce"
        self.toppings.append("Sliced Pepperoni")
        
class NYClamPizza(Pizza):
    def __init__(self):
        super().__init__()
        self.name = "NY Style Sauce and Clam Pizza"
        self.dough = "Thin Crust Dough"
        self.sauce = "Marinara Sauce"
        self.toppings.append("Fresh Clams")
        
class ChicagoCheesePizza(Pizza):
    def __init__(self):
        super().__init__()        
        self.name = "Chicago Style Deep Dish Cheese Pizza"
        self.dough = "Extra Thick Crust Dough"
        self.sauce = "Plum Tomato Sauce"
        self.toppings.append("Mozzarella Cheese")
        
class ChicagoPepperoniPizza(Pizza):
    def __init__(self):
        super().__init__()
        self.name = "Chicago Style Deep Dish Pepperoni Pizza"
        self.dough = "Extra Thick Crust Dough"
        self.sauce = "Plum Tomato Sauce"
        self.toppings.append("Pepperoni")
        
class ChicagoClamPizza(Pizza):
    def __init__(self):
        super().__init__()
        self.name = "Chicago Style Deep Dish Clam Pizza"
        self.dough = "Extra Thick Crust Dough"
        self.sauce = "Plum Tomato Sauce"
        self.toppings.append("Frozen Clams")
        
class PizzaStore(metaclass=ABCMeta):
    def orderPizza(self, pizza_type):
        pizza = self.createPizza(pizza_type)
        pizza.prepare()
        pizza.bake()
        pizza.cut()
        pizza.box()
        return pizza
    
    @abstractmethod
    def createPizza(self, pizza_type):
        pass
    
class NYPizzaStore(PizzaStore):
    def createPizza(self, pizza_type):
        if pizza_type == "cheese":
            return NYCheesePizza()
        elif pizza_type == "pepperoni":
            return NYPepperoniPizza()
        elif pizza_type == "clam":
            return NYClamPizza()
        else:
            raise ValueError(f"Unknown pizza type: {pizza_type}")

class ChicagoPizzaStore(PizzaStore):
    def createPizza(self, pizza_type):
        if pizza_type == "cheese":
            return ChicagoCheesePizza()
        elif pizza_type == "pepperoni":
            return ChicagoPepperoniPizza()
        elif pizza_type == "clam":
            return ChicagoClamPizza()
        else:
            raise ValueError(f"Unknown pizza type: {pizza_type}")

if __name__ == '__main__':
    with PyCallGraph(output=test):
        ny_pizza = NYPizzaStore()
        chicago_pizza = ChicagoPizzaStore()
        
        pizza_type = input("Enter the type of pizza you want from NY (cheese/pepperoni/clam): ")
        ny_pizza.orderPizza(pizza_type)
        
        pizza_type = input("Enter the type of pizza you want from Chicago (cheese/pepperoni/clam): ")
        chicago_pizza.orderPizza(pizza_type)