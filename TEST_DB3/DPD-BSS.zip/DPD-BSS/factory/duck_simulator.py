from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
from abc import ABC, abstractmethod

test = GraphvizOutput()
test.output_file = "duck_simulator.json"
test.output_type = 'json'

# Abstract base classes
class Quackable(ABC):
    @abstractmethod
    def quack(self):
        pass

class AbstractDuckFactory(ABC):
    @abstractmethod
    def create_mallard_duck(self) -> Quackable:
        pass

    @abstractmethod
    def create_rubber_duck(self) -> Quackable:
        pass

    @abstractmethod
    def create_duck_call(self) -> Quackable:
        pass

    @abstractmethod
    def create_redhead_duck(self) -> Quackable:
        pass

# Concrete duck classes
class MallardDuck(Quackable):
    def quack(self):
        print("Quack")

class RubberDuck(Quackable):
    def quack(self):
        print("Squeak")

class DuckCall(Quackable):
    def quack(self):
        print("Kwak")

class RedheadDuck(Quackable):
    def quack(self):
        print("Quack")

# Goose and adapter
class Goose:
    def honk(self):
        print("Honk")

class GooseAdapter(Quackable):
    def __init__(self, goose: Goose):
        self.goose = goose

    def quack(self):
        self.goose.honk()

# QuackCounter decorator
class QuackCounter(Quackable):
    quacks = 0

    def __init__(self, duck: Quackable):
        self.duck = duck

    def quack(self):
        self.duck.quack()
        QuackCounter.quacks += 1

    @staticmethod
    def get_quacks():
        return QuackCounter.quacks

# Concrete factory
class CountingDuckFactory(AbstractDuckFactory):
    def create_mallard_duck(self) -> Quackable:
        return QuackCounter(MallardDuck())

    def create_rubber_duck(self) -> Quackable:
        return QuackCounter(RubberDuck())

    def create_duck_call(self) -> Quackable:
        return QuackCounter(DuckCall())

    def create_redhead_duck(self) -> Quackable:
        return QuackCounter(RedheadDuck())

# Duck simulator
class DuckSimulator:
    @staticmethod
    def simulate():
        duck_factory = CountingDuckFactory()
        mallard_duck = duck_factory.create_mallard_duck()
        rubber_duck = duck_factory.create_rubber_duck()
        duck_call = duck_factory.create_duck_call()
        red_head_duck = duck_factory.create_redhead_duck()
        goose_duck = GooseAdapter(Goose())

        def inner_simulate(duck):
            duck.quack()

        inner_simulate(mallard_duck)
        inner_simulate(rubber_duck)
        inner_simulate(duck_call)
        inner_simulate(red_head_duck)
        inner_simulate(goose_duck)
        print(f"The ducks quacked {QuackCounter.get_quacks()} times")

if __name__ == '__main__':
    with PyCallGraph(output=test):
        DuckSimulator().simulate()