from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "factory_generic.json"
test.output_type = 'json'

# source : https://www.tutorialspoint.com/python_design_patterns/python_design_patterns_strategy.htm
# with small adaptations to keep same style across examples


if __name__ == "__main__":
    with PyCallGraph(output=test):
        pass