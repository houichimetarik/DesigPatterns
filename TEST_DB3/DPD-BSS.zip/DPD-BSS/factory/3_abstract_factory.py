from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "3_abstract_factory.json"
test.output_type = 'json'

from abc import ABC
from enum import Enum, auto


class HotDrink(ABC):
    def consume(self):
        pass


class Tea(HotDrink):
    def consume(self):
        print('This tea is nice but I\'d prefer it with milk')


class Coffee(HotDrink):
    def consume(self):
        print('This coffee is delicious')


class HotDrinkFactory(ABC):
    def prepare(self, amount):
        pass


class TeaFactory(HotDrinkFactory):
    def prepare(self, amount):
        print(f'Put in tea bag, boil water, pour {amount}ml, enjoy!')
        return Tea()


class CoffeeFactory(HotDrinkFactory):
    def prepare(self, amount):
        print(f'Grind some beans, boil water, pour {amount}ml, enjoy!')
        return Coffee()


class HotDrinkMachine:
    class AvailableDrink(Enum):  # violates OCP
        COFFEE = auto()
        TEA = auto()

    factories = []
    initialized = False

    def __init__(self):
        if not self.initialized:
            self.initialized = True
            for d in self.AvailableDrink:
                name = d.name[0] + d.name[1:].lower()
                factory_name = name + 'Factory'
                factory_instance = eval(factory_name)()
                self.factories.append((name, factory_instance))

    def make_drink(self):
        print('Available drinks:')
        for i, f in enumerate(self.factories):
            print(f'{i}: {f[0]}')

        while True:
            s = input(f'Please pick drink (0-{len(self.factories)-1}): ')
            if s.strip() == '':
                print("Invalid input. Please enter a number.")
                continue
            try:
                idx = int(s)
                if 0 <= idx < len(self.factories):
                    break
                else:
                    print(f"Please enter a number between 0 and {len(self.factories)-1}")
            except ValueError:
                print("Invalid input. Please enter a number.")

        while True:
            s = input(f'Specify amount: ')
            if s.strip() == '':
                print("Invalid input. Please enter a number.")
                continue
            try:
                amount = int(s)
                if amount > 0:
                    break
                else:
                    print("Please enter a positive number.")
            except ValueError:
                print("Invalid input. Please enter a number.")

        return self.factories[idx][1].prepare(amount)


def make_drink(type):
    if type == 'tea':
        return TeaFactory().prepare(200)
    elif type == 'coffee':
        return CoffeeFactory().prepare(50)
    else:
        return None


if __name__ == '__main__':
    with PyCallGraph(output=test):
        # entry = input('What kind of drink would you like?')
        # drink = make_drink(entry)
        # drink.consume()
    
        hdm = HotDrinkMachine()
        drink = hdm.make_drink()
        drink.consume()