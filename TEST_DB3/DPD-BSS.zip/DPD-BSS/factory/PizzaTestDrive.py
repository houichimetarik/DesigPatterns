from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
from abc import ABC, abstractmethod

test = GraphvizOutput()
test.output_file = "PizzaTestDrive.json"
test.output_type = 'json'

# Abstract classes
class Pizza(ABC):
    def __init__(self):
        self.name = ""
        self.dough = ""
        self.sauce = ""
        self.toppings = []

    def prepare(self):
        print(f"Preparing {self.name}")
        print("Tossing dough...")
        print("Adding sauce...")
        print("Adding toppings: ")
        for topping in self.toppings:
            print(f"  {topping}")

    def bake(self):
        print("Bake for 25 minutes at 350")

    def cut(self):
        print("Cutting the pizza into diagonal slices")

    def box(self):
        print("Place pizza in official PizzaStore box")

    def get_name(self):
        return self.name

class PizzaStore(ABC):
    @abstractmethod
    def create_pizza(self, item):
        pass

    def order_pizza(self, type):
        pizza = self.create_pizza(type)
        print(f"--- Making a {pizza.get_name()} ---")
        pizza.prepare()
        pizza.bake()
        pizza.cut()
        pizza.box()
        return pizza

# Concrete classes for NY Style
class NYStyleVeggiePizza(Pizza):
    def __init__(self):
        super().__init__()
        self.name = "NY Style Veggie Pizza"
        self.dough = "Thin Crust Dough"
        self.sauce = "Marinara Sauce"
        self.toppings = ["Grated Reggiano Cheese", "Garlic", "Onion", "Mushrooms", "Red Pepper"]

class NYPizzaStore(PizzaStore):
    def create_pizza(self, item):
        if item == "veggie":
            return NYStyleVeggiePizza()
        # Add other pizza types here if needed
        else:
            return None

# Concrete classes for Chicago Style
class ChicagoStyleVeggiePizza(Pizza):
    def __init__(self):
        super().__init__()
        self.name = "Chicago Style Veggie Pizza"
        self.dough = "Extra Thick Crust Dough"
        self.sauce = "Plum Tomato Sauce"
        self.toppings = ["Shredded Mozzarella Cheese", "Black Olives", "Spinach", "Eggplant"]

    def cut(self):
        print("Cutting the pizza into square slices")

class ChicagoPizzaStore(PizzaStore):
    def create_pizza(self, item):
        if item == "veggie":
            return ChicagoStyleVeggiePizza()
        # Add other pizza types here if needed
        else:
            return None

if __name__ == '__main__':
    with PyCallGraph(output=test):
        nyStore = NYPizzaStore()
        chicagoStore = ChicagoPizzaStore()
    
        pizza = nyStore.order_pizza('veggie')
        print('Ethan ordered a', pizza.get_name())
        print('')
    
        pizza = chicagoStore.order_pizza('veggie')
        print('Joel ordered a', pizza.get_name())