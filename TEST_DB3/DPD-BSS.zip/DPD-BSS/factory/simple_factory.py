from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "simple_factory.json"
test.output_type = 'json'

from abc import ABCMeta, abstractmethod

class Animal(metaclass=ABCMeta):
    @abstractmethod
    def falar(self):
        pass

class Cachorro(Animal):
    def falar(self):
        print('Au Au')

class Gato(Animal):
    def falar(self):
        print('Miau')

# Fabrica
class Fabrica:
    def criar_animal_falante(self, tipo):
        if tipo == "Cachorro":
            return Cachorro()
        elif tipo == "Gato":
            return Gato()
        else:
            raise ValueError(f"Animal desconhecido: {tipo}")

# Cliente
if __name__ == '__main__':
    with PyCallGraph(output=test):
        fab = Fabrica()
        animal = input('Qual animal vocÃª quer que fale? [Cachorro/Gato] ')
        fab.criar_animal_falante(animal).falar()