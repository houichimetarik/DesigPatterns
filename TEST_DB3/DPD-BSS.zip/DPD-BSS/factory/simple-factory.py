from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "simple-factory.json"
test.output_type = 'json'

from abc import ABCMeta, abstractmethod

class Pizza(metaclass = ABCMeta):
    def __init__(self):
        self.name = None
        self.toppings = []
     
    def prepare(self):
        print(f"Preparing {self.name}")
        print("Tossing dough...")
        print("Adding sauce...")
        print("Adding toppings:")
        for topping in self.toppings:
            print(f"    {topping}")
            
    def bake(self): 
        print("Bake for 25 minutes at 350")
        
    def cut(self):
        print("Cutting the pizza into diagonal slices")
        
    def box(self):
        print("Place pizza in official PizzaStore box")
        
    def getName(self):
        return self.name
    
class CheesePizza(Pizza):
    def __init__(self):
        super().__init__()        
        self.name = "Cheese Pizza"
        self.toppings.append("Grated Reggiano Cheese")
        
class PepperoniPizza(Pizza):
    def __init__(self):
        super().__init__()
        self.name = "Pepperoni Pizza"
        self.toppings.append("Shredded Mozzarella Cheese")
        
class ClamPizza(Pizza):
    def __init__(self):
        super().__init__()
        self.name = "Clam Pizza"
        self.toppings.append("Seafood Cheese")
    
class SimplePizzaFactory:
    def createPizza(self, pizza_type):
        if pizza_type.lower() == "c":
            return CheesePizza()
        elif pizza_type.lower() == "pepperoni":
            return PepperoniPizza()
        elif pizza_type.lower() == "clam":
            return ClamPizza()
        else:
            raise ValueError(f"Unknown pizza type: {pizza_type}")
        
class PizzaStore:
    def __init__(self, factory):
        self.factory = factory
        
    def orderPizza(self, pizza_type):
        pizza = self.factory.createPizza(pizza_type)
        if pizza is None:
            print(f"Sorry, we don't have {pizza_type} pizza.")
            return None
        
        pizza.prepare()
        pizza.bake()
        pizza.cut()
        pizza.box()
        return pizza

if __name__ == '__main__':
    with PyCallGraph(output=test):
        pf = SimplePizzaFactory()
        pizza_type = input("Enter the type of pizza you want: ")
        pizza = PizzaStore(pf).orderPizza(pizza_type)
        if pizza:
            print(f"Enjoy your {pizza.getName()}!")