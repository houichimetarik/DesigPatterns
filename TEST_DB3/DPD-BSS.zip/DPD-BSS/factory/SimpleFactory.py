from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "SimpleFactory.json"
test.output_type = 'json'

"""
Created on Mon Jul 27 13:12:14 2020.

@author: fuhr
"""

from abc import ABCMeta, abstractmethod


class Animal(metaclass=ABCMeta):
    """Abstract class for animals."""

    @abstractmethod
    def do_say(self):
        """Abstract method to print the animal sound."""
        pass


class Dog(Animal):
    """Class to define a dog."""

    def do_say(self):
        """Print the sound of a dog."""
        print("Au au!")


class Cat(Animal):
    """Class to define a cat."""

    def do_say(self):
        """Print the sound of a cat."""
        print("Miau miau!")


class ForestFactory(object):
    """Class to define a forest Simple Factory."""

    def make_sound(self, object_type):
        """Call the do_say method from the desired class."""
        if object_type.lower() == 'dog':
            return Dog().do_say()
        elif object_type.lower() == 'cat':
            return Cat().do_say()
        else:
            raise ValueError("Invalid animal type. Choose 'Dog' or 'Cat'.")


# Client code
if __name__ == '__main__':
    with PyCallGraph(output=test):
        ff = ForestFactory()
        animal = input("Which animal should make_sound Dog or Cat? ")
        ff.make_sound(animal)