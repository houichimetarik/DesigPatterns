
from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "factory_method_2.json"
test.output_type = 'json'

# -*- coding: utf-8 -*-
from abc import ABCMeta, abstractmethod

class Secao(metaclass=ABCMeta):

    @abstractmethod
    def __repr__(self):
        pass

class SecaoPessoal(Secao):

    def __repr__(self):
        return 'Seção Pessoal'

class SecaoAlbum(Secao):

    def __repr__(self):
        return 'Seção Album'

class SecaoProjeto(Secao):

    def __repr__(self):
        return 'Seção Projeto'

class SecaoPublicacao(Secao):

    def __repr__(self):
        return 'Seção Publicação'

class Perfil(metaclass=ABCMeta):

    def __init__(self):
        self.secoes = []
        self.criar_perfil()

    @abstractmethod
    def criar_perfil(self):
        pass
    
    def get_secoes(self):
        return self.secoes

    def add_sessao(self, secao):
        self.secoes.append(secao)

class LinkedIn(Perfil):

    def criar_perfil(self):
        self.add_sessao(SecaoPessoal())
        self.add_sessao(SecaoProjeto())
        self.add_sessao(SecaoPublicacao())
    
class Facebook(Perfil):

    def criar_perfil(self):
        self.add_sessao(SecaoPessoal())
        self.add_sessao(SecaoAlbum())

def criar_perfil(rede_social: str) -> Perfil:
    rede_social = rede_social.lower()
    if rede_social == 'linkedin':
        return LinkedIn()
    elif rede_social == 'facebook':
        return Facebook()
    else:
        raise ValueError(f"Rede social desconhecida: {rede_social}")

if __name__ == '__main__':
    with PyCallGraph(output=test):
        rede_social = input('Qual rede social quer criar o perfil? [LinkedIn / Facebook] ')
        
        try:
            perfil = criar_perfil(rede_social)
            print(f'Criando perfil no {type(perfil).__name__}')
            print(f'O perfil tem as seções {perfil.get_secoes()}')
        except ValueError as e:
            print(f"Erro: {e}")