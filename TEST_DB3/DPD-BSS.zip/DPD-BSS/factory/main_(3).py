from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
from abc import ABC, abstractmethod

test = GraphvizOutput()
test.output_file = "main_(3).json"
test.output_type = 'json'

# Credit Card class
class CreditCard:
    def __init__(self, owner: str):
        self.owner = owner

    def use(self):
        print(f"{self.owner} is using their credit card.")

# CreditCardFactory class
class CreditCardFactory:
    def create(self, owner: str) -> CreditCard:
        return CreditCard(owner)

'''
The subject is a factory to make credit cards. The Factory defines how to create a credit card,
but the actual credit card is created by the CreditCardFactory.
The "create()" method is called a Factory Method, and it is responsible for manufacturing an object.
'''

if __name__ == '__main__':
    with PyCallGraph(output=test):
        factory = CreditCardFactory()
    
        jackson_card = factory.create(owner='Jackson')
        jackson_card.use()
    
        sophia_card = factory.create(owner='Sophia')
        sophia_card.use()
    
        olivia_card = factory.create(owner='Olivia')
        olivia_card.use()