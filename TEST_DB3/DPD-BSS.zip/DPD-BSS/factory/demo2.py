from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "demo2.json"
test.output_type = 'json'

#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   demo2.py
@Time    :   2020/03/22 18:03:09
@Author  :   Vadon Mo
@Version :   1.0
@Contact :   vadonmo@126.com
@License :   Code Project Open License (CPOL)
@Desc    :   父类不参与创建，交由子类创建
'''

from abc import ABCMeta, abstractmethod


class Section(metaclass=ABCMeta):
    @abstractmethod
    def describe(self):
        pass
    pass


class PersonalSection(Section):
    def describe(self):
        print("Personal Section")
    pass


class AlbumSection(Section):
    def describe(self):
        print("Album Section")
    pass


class PatentSection(Section):
    def describe(self):
        print("Patent Section")
    pass


class PublicationSection(Section):
    def describe(self):
        print("Publication Section")
    pass


class Profile(metaclass=ABCMeta):
    def __init__(self):
        self.sections = []
        self.createProfile()

    @abstractmethod
    def createProfile(self):
        pass

    def getSections(self):
        return self.sections

    def addSections(self, section):
        self.sections.append(section)


class linkedin(Profile):
    def createProfile(self):
        self.addSections(PersonalSection())
        self.addSections(PatentSection())
        self.addSections(PublicationSection())


class facebook(Profile):
    def createProfile(self):
        self.addSections(PersonalSection())
        self.addSections(AlbumSection())


def create_profile(profile_type: str) -> Profile:
    profile_type = profile_type.lower()
    if profile_type == 'linkedin':
        return linkedin()
    elif profile_type == 'facebook':
        return facebook()
    else:
        raise ValueError(f"Unknown profile type: {profile_type}")

if __name__ == "__main__":
    test = GraphvizOutput()
    test.output_file = "demo2.json"
    test.output_type = 'json'

    with PyCallGraph(output=test):
        profile_type = input("Which Profile you'd like to create? [LinkedIn or Facebook] ")
        try:
            profile = create_profile(profile_type)
            print("Creating Profile...", type(profile).__name__)
            print("Profile has sections --", profile.getSections())
        except ValueError as e:
            print(f"Error: {e}")