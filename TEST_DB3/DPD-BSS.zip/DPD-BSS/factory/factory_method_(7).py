from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
import sys
import io

test = GraphvizOutput()
test.output_file = "factory_method_(7).json"
test.output_type = 'json'

class GreekGetter:
    def __init__(self):
        self.trans = dict(dog="σκύλος", cat="γάτα")

    def get(self, msgid):
        return self.trans.get(msgid, str(msgid))

class EnglishGetter:
    def get(self, msgid):
        return str(msgid)

def get_localizer(language="English"):
    languages = dict(English=EnglishGetter, Greek=GreekGetter)
    return languages[language]()

def safe_print(*args, **kwargs):
    buffer = io.StringIO()
    print(*args, file=buffer, **kwargs)
    output = buffer.getvalue()
    buffer.close()
    try:
        sys.stdout.buffer.write(output.encode('utf-8'))
    except AttributeError:
        print(output.encode('ascii', errors='replace').decode('ascii'))

if __name__ == '__main__':
    with PyCallGraph(output=test):
        e, g = get_localizer(language="English"), get_localizer(language="Greek")
        for msgid in "dog parrot cat bear".split():
            safe_print(e.get(msgid), g.get(msgid))

    # Writing output to a file as a fallback
    with open('output.txt', 'w', encoding='utf-8') as f:
        e, g = get_localizer(language="English"), get_localizer(language="Greek")
        for msgid in "dog parrot cat bear".split():
            f.write(f"{e.get(msgid)} {g.get(msgid)}\n")
    print("Output also written to output.txt")

### OUTPUT ###
# dog σκύλος
# parrot parrot
# cat γάτα
# bear bear