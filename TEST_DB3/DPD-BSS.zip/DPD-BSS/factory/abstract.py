from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "abstract.json"
test.output_type = 'json'

from abc import ABC
from enum import Enum


class HotDrink(ABC):

    def consume(self):
        pass


class Tea(HotDrink):

    def consume(self):
        print('Drinking tea...')


class Coffee(HotDrink):

    def consume(self):
        print('Drinking coffee...')


class HotDrinkFactory(ABC):

    def prepare(self):
        pass


class TeaFactory(HotDrinkFactory):

    def prepare(self, amount):
        print(f'Preparing {amount}ml of tea...')
        return Tea()


class CoffeeFactory(HotDrinkFactory):

    def prepare(self, amount):
        print(f'Preparing {amount}ml of coffee...')
        return Coffee()


class HotDrinkMachine:

    class AvailableHotDrinks(Enum):
        TEA = 1
        COFFEE = 2

    factories = []
    initialized = False

    def __init__(self):
        if not self.initialized:
            self.initialized = True
            for drink in self.AvailableHotDrinks:
                name = drink.name.capitalize()
                factory_name = name + 'Factory'
                factory_instance = eval(factory_name)()
                self.factories.append((name, factory_instance))

    def receive_order(self):
        print('Available drinks:')
        cnt = -1
        for factory in self.factories:
            cnt += 1
            print(cnt, factory[0])

        while True:
            idx = input(f'Please order a drink (0~{cnt}): ')
            if idx.strip() and idx.isdigit() and 0 <= int(idx) <= cnt:
                break
            print(f"Invalid input. Please enter a number between 0 and {cnt}.")

        while True:
            amt = input('Please specify amount (ml): ')
            if amt.strip() and amt.isdigit() and int(amt) > 0:
                break
            print("Invalid input. Please enter a positive number.")

        return self.factories[int(idx)][1].prepare(int(amt))


if __name__ == "__main__":
    with PyCallGraph(output=test):
        hdm = HotDrinkMachine()
        drink = hdm.receive_order()
        drink.consume()