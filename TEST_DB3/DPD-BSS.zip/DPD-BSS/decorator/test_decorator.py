from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "test_decorator.json"
test.output_type = 'json'

import unittest
from abc import ABC, abstractmethod

__author__ = 'Bruno'

# Abstract base class for Hamburger
class HamburgerInterface(ABC):
    @abstractmethod
    def price(self) -> float:
        pass

    @abstractmethod
    def description(self) -> str:
        pass

# Concrete Hamburger class
class Hamburger(HamburgerInterface):
    def price(self) -> float:
        return 5.0

    def description(self) -> str:
        return 'A Big Mac'

# Abstract base class for Hamburger decorators
class HamburgerDecorator(HamburgerInterface):
    def __init__(self, hamburger: HamburgerInterface):
        self._hamburger = hamburger

    @abstractmethod
    def price(self) -> float:
        pass

    @abstractmethod
    def description(self) -> str:
        pass

# Concrete decorator classes
class CheeseDecorator(HamburgerDecorator):
    def price(self) -> float:
        return self._hamburger.price() + 1.0

    def description(self) -> str:
        return f'{self._hamburger.description()}, with cheese'

class BaconDecorator(HamburgerDecorator):
    def price(self) -> float:
        return self._hamburger.price() + 2.0

    def description(self) -> str:
        return f'{self._hamburger.description()}, with bacon'

class SaladDecorator(HamburgerDecorator):
    def price(self) -> float:
        return self._hamburger.price() + 3.0

    def description(self) -> str:
        return f'{self._hamburger.description()}, with salad'

class Test(unittest.TestCase):
    def test_just_hamburger(self):
        hamburger = Hamburger()
        assert hamburger.price() == 5
        assert hamburger.description() == 'A Big Mac'

    def test_hamburger_with_everything(self):
        hamburger = SaladDecorator(BaconDecorator(CheeseDecorator(Hamburger())))
        assert hamburger.price() == 11
        assert hamburger.description() == 'A Big Mac, with cheese, with bacon, with salad'


if __name__ == '__main__':
    with PyCallGraph(output=test):
        unittest.main()