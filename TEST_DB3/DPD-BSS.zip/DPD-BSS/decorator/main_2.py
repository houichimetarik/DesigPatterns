from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "main_2.json"
test.output_type = 'json'

from abc import ABC, abstractmethod

class Pizza(ABC):
    @abstractmethod
    def cost(self) -> float:
        pass

class FarmHousePizza(Pizza):
    def cost(self) -> float:
        return 200.0

class PizzaDecorator(Pizza):
    def __init__(self, pizza: Pizza):
        self._pizza = pizza

    @abstractmethod
    def cost(self) -> float:
        pass

class CheeseTopping(PizzaDecorator):
    def cost(self) -> float:
        return self._pizza.cost() + 80.0

if __name__ == "__main__":
    with PyCallGraph(output=test):
        topped_pizza = CheeseTopping(FarmHousePizza())
        print(f"Cost of topped pizza = {topped_pizza.cost()}")