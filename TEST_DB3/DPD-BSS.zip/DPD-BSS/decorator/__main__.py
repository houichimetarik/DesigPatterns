from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "__main__.json"
test.output_type = 'json'

class Economy:
    def __init__(self):
        self.description = "Economy"
        self.cost = 16000.00

class CarDecorator:
    def __init__(self, car):
        self.car = car

    @property
    def description(self):
        return self.car.description

    @property
    def cost(self):
        return self.car.cost

class V6(CarDecorator):
    @property
    def description(self):
        return self.car.description + ", V6"

    @property
    def cost(self):
        return self.car.cost + 1200.00

class Vinyl(CarDecorator):
    @property
    def description(self):
        return self.car.description + ", Vinyl"

    @property
    def cost(self):
        return self.car.cost + 250.00

class Black(CarDecorator):
    @property
    def description(self):
        return self.car.description + ", Black"

    @property
    def cost(self):
        return self.car.cost + 100.00

def main():
    car = Economy()
    show(car)
    car = V6(car)
    show(car)
    car = Vinyl(car)
    show(car)
    car = Black(car)
    show(car)

def show(car):
    print("Description: {}; cost: ${}".format(car.description, car.cost))

if __name__ == "__main__":
    with PyCallGraph(output=test):
        main()