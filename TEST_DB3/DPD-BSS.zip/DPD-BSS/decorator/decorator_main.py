from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
from abc import ABC, abstractmethod

test = GraphvizOutput()
test.output_file = "decorator_main.json"
test.output_type = 'json'

class OrderComponent(ABC):
    @abstractmethod
    def print(self, scenario: str):
        pass

class Order(OrderComponent):
    def print(self, scenario: str):
        print(f"Basic order - {scenario}")

class OrderDecorator(OrderComponent):
    def __init__(self, order: OrderComponent):
        self._order = order

    @abstractmethod
    def print(self, scenario: str):
        pass

class GiftOrderDecorator(OrderDecorator):
    def print(self, scenario: str):
        self._order.print(scenario)
        print("Gift wrap added")

class ExpressOrderDecorator(OrderDecorator):
    def print(self, scenario: str):
        self._order.print(scenario)
        print("Express shipping added")

if __name__ == "__main__":
    with PyCallGraph(output=test):
        # Scenario 1: Basic order
        Order().print("scenario_1")
        print('-' * 16)

        # Scenario 2: Order with gift wrap and express shipping
        express_gift_order = ExpressOrderDecorator(GiftOrderDecorator(Order()))
        express_gift_order.print("scenario_2")