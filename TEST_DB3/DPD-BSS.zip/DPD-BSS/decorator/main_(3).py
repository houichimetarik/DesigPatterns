from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "main_(3).json"
test.output_type = 'json'

from abc import ABC, abstractmethod
from typing import List

class Display(ABC):
    @abstractmethod
    def get_columns(self) -> int:
        pass

    @abstractmethod
    def get_rows(self) -> int:
        pass

    @abstractmethod
    def get_row_text(self, row: int) -> str:
        pass

    def show(self) -> None:
        for i in range(self.get_rows()):
            print(self.get_row_text(i))

class MessageDisplay(Display):
    def __init__(self, message: str):
        self.__message = message

    def get_columns(self) -> int:
        return len(self.__message)

    def get_rows(self) -> int:
        return 1

    def get_row_text(self, row: int) -> str:
        if row == 0:
            return self.__message
        else:
            return None

class SideFrame(Display):
    def __init__(self, display: Display, frame_char: str):
        self.__display = display
        self.__frame_char = frame_char

    def get_columns(self) -> int:
        return 1 + self.__display.get_columns() + 1

    def get_rows(self) -> int:
        return self.__display.get_rows()

    def get_row_text(self, row: int) -> str:
        return self.__frame_char + self.__display.get_row_text(row) + self.__frame_char

class FullFrame(Display):
    def __init__(self, display: Display):
        self.__display = display

    def get_columns(self) -> int:
        return 1 + self.__display.get_columns() + 1

    def get_rows(self) -> int:
        return 1 + self.__display.get_rows() + 1

    def get_row_text(self, row: int) -> str:
        if row == 0 or row == self.get_rows() - 1:
            return '+' + '-' * self.__display.get_columns() + '+'
        else:
            return '|' + self.__display.get_row_text(row - 1) + '|'

if __name__ == '__main__':
    with PyCallGraph(output=test):
        display_a: Display = MessageDisplay(message='Nice to meet you.')
        display_a.show()
    
        display_b: Display = SideFrame(display=MessageDisplay(message='Nice to meet you.'), frame_char='!')
        display_b.show()
    
        display_c: Display = FullFrame(display=SideFrame(display=MessageDisplay(message='Nice to meet you.'), frame_char='!'))
        display_c.show()
        