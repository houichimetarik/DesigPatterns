from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "main_13.json"
test.output_type = 'json'

from typing import List
from abc import ABC, abstractmethod
from enum import Enum

class PizzaSize(Enum):
    SMALL = 1
    MEDIUM = 2
    LARGE = 3

class PizzaIngredient(ABC):
    @abstractmethod
    def get_cost(self) -> float:
        pass

    @abstractmethod
    def get_description(self) -> str:
        pass

class PizzaDough(PizzaIngredient):
    def __init__(self, size: PizzaSize):
        self.size = size

class NeapolitanPizza(PizzaDough):
    def get_cost(self) -> float:
        if self.size == PizzaSize.SMALL:
            return 5.0
        elif self.size == PizzaSize.MEDIUM:
            return 7.0
        else:
            return 9.0

    def get_description(self) -> str:
        return f"Neapolitan Pizza ({self.size.name})"

class PizzaTopping(PizzaIngredient):
    def __init__(self, pizza: PizzaIngredient):
        self.pizza = pizza

    def get_cost(self) -> float:
        return self.pizza.get_cost() + self.ingredient_cost()

    def get_description(self) -> str:
        return f"{self.pizza.get_description()}, {self.ingredient_name()}"

    @abstractmethod
    def ingredient_cost(self) -> float:
        pass

    @abstractmethod
    def ingredient_name(self) -> str:
        pass

class MarinaraSauce(PizzaTopping):
    def ingredient_cost(self) -> float:
        return 0.5

    def ingredient_name(self) -> str:
        return "Marinara Sauce"

class Cheese(PizzaTopping):
    def ingredient_cost(self) -> float:
        return 1.0

    def ingredient_name(self) -> str:
        return "Cheese"

class Pepperoni(PizzaTopping):
    def ingredient_cost(self) -> float:
        return 1.5

    def ingredient_name(self) -> str:
        return "Pepperoni"

class PizzaOrder:
    def __init__(
        self,
        dough: PizzaDough,
        ingredients: List[type[PizzaTopping]],
    ):
        self._dough = dough
        self._ingredients = ingredients
        self._pizza = self.compose_pizza()

    def compose_pizza(self) -> PizzaIngredient:
        pizza: PizzaIngredient = self._dough

        for ingredient in self._ingredients:
            pizza = ingredient(pizza)

        return pizza

    def get_total_cost(self) -> float:
        return self._pizza.get_cost()

    def get_full_description(self) -> str:
        return self._pizza.get_description()

    def __str__(self) -> str:
        return self.get_full_description() + "\n--------------------" + f"\nTotal cost: ${self.get_total_cost():.2f}"

if __name__ == "__main__":
    with PyCallGraph(output=test):
        pizza_dough = NeapolitanPizza(PizzaSize.SMALL)
        ingredients = [
            MarinaraSauce,
            Cheese,
            Pepperoni,
            Pepperoni,
        ]
    
        pizza_order = PizzaOrder(dough=pizza_dough, ingredients=ingredients)
    
        print(pizza_order)