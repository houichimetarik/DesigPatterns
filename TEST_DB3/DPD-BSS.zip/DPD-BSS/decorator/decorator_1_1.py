from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "decorator_1_1.json"
test.output_type = 'json'

import abc


class Component(abc.ABC):
    
    @abc.abstractmethod
    def operation(self):
        pass


class Decorator(Component, abc.ABC):
    
    def __init__(self, component):
        self.component = component

    @abc.abstractmethod
    def operation(self):
        pass


class ConcreteComponent(Component):
    
    def operation(self):
        print('Do something from ConcreteComponent')


class ConcreteDecorator(Decorator):

    def operation(self):
        print('Do something decorated')
        self.component.operation()


if __name__ == '__main__':
    with PyCallGraph(output=test):
        component = ConcreteComponent()
        decorator = ConcreteDecorator(component)
        decorator.operation()