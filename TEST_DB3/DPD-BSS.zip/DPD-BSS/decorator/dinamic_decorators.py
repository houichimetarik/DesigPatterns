from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
import os

test = GraphvizOutput()
test.output_file = "dinamic_decorators.json"
test.output_type = 'json'

class FileWithLogging:
    def __init__(self, file):
        self.file = file

    def write(self, text):
        print(f'Writing {text} to {self.file.name}')
        self.file.write(text)
        
    def __iter__(self):
        return self.file.__iter__()
    
    def __next__(self):
        return next(self.file)

    def __getattr__(self, item):
        return getattr(self.file, item)
    
    def __setattr__(self, key, value) -> None:
        if key == 'file':
            self.__dict__[key] = value
        else:
            setattr(self.file, key, value)
    
    def __delattr__(self, item) -> None:
        if item == 'file':
            raise AttributeError("Can't delete file")
        else:
            delattr(self.file, item)
            
if __name__ == "__main__":
    with PyCallGraph(output=test):
        # Create the directory if it doesn't exist
        os.makedirs('Decorator/files', exist_ok=True)
        
        file_path = 'Decorator/files/some_file.txt'
        with open(file_path, 'w') as f:
            f = FileWithLogging(f)
            f.write('hello world')
        
        # Read and print the contents of the file to verify
        with open(file_path, 'r') as f:
            print(f"File contents: {f.read()}")