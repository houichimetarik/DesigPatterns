from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "Decorator_3_(4).json"
test.output_type = 'json'

class Component:
    def operation(self):
        pass


class ComponentOne(Component):
    def operation(self):
        return "ComponentOne: operation"


class Decorator(Component):
    __component = None

    def __init__(self, component):
        self.__component = component

    @property
    def component(self):
        return self.__component

    def operation(self):
        return self.__component.operation()


class DecoratorOne(Decorator):
    def operation(self):
        print("\tDecoratorOne: Operation One")
        return self.component.operation()


class DecoratorTwo(Decorator):
    def operation(self):
        print("\tDecoratorTwo: Operation Two")
        return self.component.operation()


if __name__ == "__main__":
    with PyCallGraph(output=test):
        component = ComponentOne()
        print(component.operation())
    
        decorator1 = DecoratorOne(component)
        print(decorator1.operation())
    
        decorator2 = DecoratorTwo(decorator1)
        print(decorator2.operation())