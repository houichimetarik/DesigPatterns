from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "oop_decorator_(2).json"
test.output_type = 'json'

from abc import ABC


class Shape(ABC):
    def __str__(self):
        return ''


class Circle(Shape):
    def __init__(self, radius=0.0):
        self.radius = radius

    def resize(self, factor):
        self.radius *= factor

    def __str__(self):
        return f'A circle of radius {self.radius}'


class Square(Shape):
    def __init__(self, side):
        self.side = side

    def __str__(self):
        return f'A square with side {self.side}'


class ColoredShape(Shape):
    def __init__(self, shape, color):
        if isinstance(shape, ColoredShape):
            raise Exception('Cannot apply ColoredDecorator twice')
        self.shape = shape
        self.color = color

    def __str__(self):
        return f'{self.shape} has the color {self.color}'


class TransparentShape(Shape):
    def __init__(self, shape, transparency):
        self.shape = shape
        self.transparency = transparency

    def __str__(self):
        return f'{self.shape} has {self.transparency * 100.0}% transparency'


if __name__ == '__main__':
    with PyCallGraph(output=test):
        circle = Circle(2)
        print(circle)
    
        red_circle = ColoredShape(circle, "brown")
        print(red_circle)
    
        red_half_transparent_circle = TransparentShape(red_circle, 0.5)
        print(red_half_transparent_circle)
    
        # To avoid the error, we'll create a different decoration
        blue_circle = ColoredShape(Circle(3), 'blue')
        print(blue_circle)

        # If you need to apply multiple colors, you could use TransparentShape instead
        red_and_transparent = TransparentShape(ColoredShape(Circle(3), 'brown'), 0.5)
        print(red_and_transparent)