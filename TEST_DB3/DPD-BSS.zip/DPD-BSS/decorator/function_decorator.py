from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "function_decorator.json"
test.output_type = 'json'

import time
from typing import Any, Callable


def time_cost(func: Callable) -> Callable:
    def wrapper(*args, **kwargs) -> Any:
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        print(f'{func.__name__} took {int((end - start) * 1000)} ms')
        return result

    return wrapper


@time_cost
def some_op():
    print('Starting op')
    time.sleep(2)
    print('We are done')
    return 1


if __name__ == '__main__':
    with PyCallGraph(output=test):
        some_op()