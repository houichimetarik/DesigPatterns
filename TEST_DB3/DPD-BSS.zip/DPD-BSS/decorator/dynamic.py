from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "dynamic.json"
test.output_type = 'json'

from typing import Any, Iterator, TextIO
import os

class FileWithLogging:

    def __init__(self, file: TextIO) -> None:
        self.file: TextIO = file

    def writelines(self, lines: list[str]) -> None:
        self.file.writelines(lines)
        print(f"Writing {len(lines)} lines")

    def __iter__(self) -> Iterator[str]:
        return self.file.__iter__()

    def __next__(self) -> str:
        return self.file.__next__()

    def __getattr__(self, item: str) -> Any:
        return getattr(self.__dict__["file"], item)

    def __setattr__(self, key: str, value: Any) -> None:
        if key == "file":
            self.__dict__["file"] = value
        else:
            setattr(self.__dict__["file"], key, value)

    def __delattr__(self, item: str) -> None:
        delattr(self.__dict__["file"], item)


if __name__ == "__main__":
    with PyCallGraph(output=test):
        os.makedirs("data", exist_ok=True)
        with open("data/hello.txt", "w", encoding="utf-8") as opened_file:
            file_with_logging = FileWithLogging(opened_file)
            file_with_logging.writelines(["hello", ", ", "world!"])
            file_with_logging.write("\ntesting")