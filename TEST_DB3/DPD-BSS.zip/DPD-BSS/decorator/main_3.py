from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "main_3.json"
test.output_type = 'json'

from abc import ABC, abstractmethod

class Car(ABC):
    @abstractmethod
    def create(self):
        pass

class Toyota(Car):
    def create(self):
        print("Creating a Toyota car")

class CarDecorator(Car):
    def __init__(self, car: Car):
        self._car = car

    @abstractmethod
    def create(self):
        pass

class BlueCarDecorator(CarDecorator):
    def create(self):
        self._car.create()
        self._add_blue_color()

    def _add_blue_color(self):
        print("Adding blue color to the car")

def main():
    toyota = Toyota()
    toyota.create()

    another_toyota = Toyota()
    blue_toyota = BlueCarDecorator(another_toyota)
    blue_toyota.create()

if __name__ == "__main__":
    with PyCallGraph(output=test):
        main()