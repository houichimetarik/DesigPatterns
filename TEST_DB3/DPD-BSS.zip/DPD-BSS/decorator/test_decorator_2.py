from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "test_decorator_2.json"
test.output_type = 'json'

import unittest
import sys
import os
from abc import ABC, abstractmethod

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

# Component interface
class Component(ABC):
    @abstractmethod
    def operation(self) -> str:
        pass

# Concrete Component
class ConcreteComponent(Component):
    def operation(self) -> str:
        return "ConcreteComponent"

# Decorator base class
class Decorator(Component):
    def __init__(self, component: Component) -> None:
        self._component = component

    @abstractmethod
    def operation(self) -> str:
        pass

# Concrete Decorator A
class ConcreteDecoratorA(Decorator):
    def operation(self) -> str:
        return f"ConcreteDecoratorA({self._component.operation()})"

# Concrete Decorator B
class ConcreteDecoratorB(Decorator):
    def operation(self) -> str:
        return f"ConcreteDecoratorB({self._component.operation()})"

class TestDecoratorPattern(unittest.TestCase):
    def test_decorator(self):
        simple = ConcreteComponent()
        decorated = ConcreteDecoratorA(simple)
        more_decorated = ConcreteDecoratorB(decorated)
        self.assertEqual(more_decorated.operation(), "ConcreteDecoratorB(ConcreteDecoratorA(ConcreteComponent))")

if __name__ == '__main__':
    with PyCallGraph(output=test):
        unittest.main()