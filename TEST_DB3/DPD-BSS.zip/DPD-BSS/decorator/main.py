from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "main.json"
test.output_type = 'json'

class Component:
    def execute(self):
        pass


class ConcreteComponent(Component):
    def execute(self):
        print("Executing ConcreteComponent")


class BaseDecorator(Component):
    _component: Component = None

    def __init__(self, component):
        self._component = component

    @property
    def component(self) -> Component:
        return self._component

    def execute(self):
        self._component.execute()


class ConcreteDecorator(BaseDecorator):
    def execute(self):
        print("Executing ConcreteDecorator")
        self.component.execute()


class ClientCode:
    def __init__(self, component):
        self.component = component

    def execute(self):
        print("Executing ClientCode:")
        self.component.execute()


if __name__ == "__main__":
    with PyCallGraph(output=test):
        component = ConcreteComponent()
        decorator = ConcreteDecorator(component)
        client = ClientCode(decorator)
        client.execute()