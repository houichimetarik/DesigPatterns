from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
from abc import ABC, abstractmethod

test = GraphvizOutput()
test.output_file = "duck_simulator.json"
test.output_type = 'json'

# Quackable interface
class Quackable(ABC):
    @abstractmethod
    def quack(self):
        pass

# Concrete duck classes
class MallardDuck(Quackable):
    def quack(self):
        print("Quack")

class RubberDuck(Quackable):
    def quack(self):
        print("Squeak")

class DuckCall(Quackable):
    def quack(self):
        print("Kwak")

class RedHeadDuck(Quackable):
    def quack(self):
        print("Quack")

# Goose class and adapter
class Goose:
    def honk(self):
        print("Honk")

class GooseAdapter(Quackable):
    def __init__(self, goose):
        self.goose = goose

    def quack(self):
        self.goose.honk()

# QuackCounter decorator
class QuackCounter(Quackable):
    quacks = 0

    def __init__(self, duck):
        self.duck = duck

    def quack(self):
        self.duck.quack()
        QuackCounter.quacks += 1

    @staticmethod
    def get_quacks():
        return QuackCounter.quacks

class DuckSimulator:
    @staticmethod
    def simulate():
        mallard_duck = QuackCounter(MallardDuck())
        rubber_duck = QuackCounter(RubberDuck())
        duck_call = QuackCounter(DuckCall())
        red_head_duck = QuackCounter(RedHeadDuck())
        goose_duck = GooseAdapter(Goose())

        def inner_simulate(duck):
            duck.quack()

        inner_simulate(mallard_duck)
        inner_simulate(rubber_duck)
        inner_simulate(duck_call)
        inner_simulate(red_head_duck)
        inner_simulate(goose_duck)
        print(f"The ducks quacked {QuackCounter.get_quacks()} times")

if __name__ == '__main__':
    with PyCallGraph(output=test):
        DuckSimulator().simulate()