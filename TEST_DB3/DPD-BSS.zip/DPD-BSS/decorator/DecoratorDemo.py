from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
from abc import ABC, abstractmethod

test = GraphvizOutput()
test.output_file = "DecoratorDemo.json"
test.output_type = 'json'

class FragStatistics(ABC):
    @abstractmethod
    def increment_death_count(self):
        pass

    @abstractmethod
    def increment_frag_count(self):
        pass

    @abstractmethod
    def get_frag_count(self) -> int:
        pass

    @abstractmethod
    def get_death_count(self) -> int:
        pass

class FirstPersonShooterFragStatistics(FragStatistics):
    def __init__(self):
        self._frag_count = 0
        self._death_count = 0

    def increment_death_count(self):
        self._death_count += 1

    def increment_frag_count(self):
        self._frag_count += 1

    def get_frag_count(self) -> int:
        return self._frag_count

    def get_death_count(self) -> int:
        return self._death_count

class FragStatisticsDecorator(FragStatistics):
    def __init__(self, frag_statistics: FragStatistics):
        self.frag_statistics = frag_statistics

    def increment_death_count(self):
        self.frag_statistics.increment_death_count()

    def increment_frag_count(self):
        self.frag_statistics.increment_frag_count()

    def get_frag_count(self) -> int:
        return self.frag_statistics.get_frag_count()

    def get_death_count(self) -> int:
        return self.frag_statistics.get_death_count()

class DeathCountInfoDecorator(FragStatisticsDecorator):
    def increment_death_count(self):
        super().increment_death_count()
        print(f"You died! Death count: {self.get_death_count()}")

class DisplayCountersDecorator(FragStatisticsDecorator):
    def increment_death_count(self):
        super().increment_death_count()
        self.display_counters()

    def increment_frag_count(self):
        super().increment_frag_count()
        self.display_counters()

    def display_counters(self):
        print(f"Frags: {self.get_frag_count()}, Deaths: {self.get_death_count()}")

class FragInfoDecorator(FragStatisticsDecorator):
    def increment_frag_count(self):
        super().increment_frag_count()
        print(f"You fragged someone! Frag count: {self.get_frag_count()}")

class FragDeathRatioDecorator(FragStatisticsDecorator):
    def increment_death_count(self):
        super().increment_death_count()
        self.display_ratio()

    def increment_frag_count(self):
        super().increment_frag_count()
        self.display_ratio()

    def display_ratio(self):
        death_count = self.get_death_count()
        ratio = self.get_frag_count() / death_count if death_count != 0 else self.get_frag_count()
        print(f"Frag/Death Ratio: {ratio:.2f}")

def main():
    statistics = FirstPersonShooterFragStatistics()

    statistics.increment_death_count()  # nothing will appear on the screen
    statistics.increment_frag_count()   # nothing will appear on the screen

    decorated_statistics = FragDeathRatioDecorator(FragInfoDecorator(DisplayCountersDecorator(DeathCountInfoDecorator(statistics))))

    decorated_statistics.increment_frag_count()
    decorated_statistics.increment_frag_count()
    decorated_statistics.increment_frag_count()
    decorated_statistics.increment_death_count()

if __name__ == '__main__':
    with PyCallGraph(output=test):
        main()