from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "main_10.json"
test.output_type = 'json'

from abc import ABC, abstractmethod

class Plant(ABC):
    @abstractmethod
    def attack(self):
        pass

class PlantDecorator(Plant):
    def __init__(self, plant: Plant):
        self._plant = plant

    @abstractmethod
    def attack(self):
        pass

class Peashooter(Plant):
    def attack(self):
        print("Peashooter attacks!")

class IceDecoratorPlant(PlantDecorator):
    def attack(self):
        self._plant.attack()
        print("Ice effect added to the attack!")

def main():
    peashooter = Peashooter()
    peashooter.attack()
    
    ice_decorator_plant = IceDecoratorPlant(peashooter)
    ice_decorator_plant.attack()

if __name__ == '__main__':
    with PyCallGraph(output=test):
        main()