from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "main_(3).json"
test.output_type = 'json'

#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os

class Database:
    def __init__(self):
        self.data = {
            'emily@example.com': {
                'name': 'Emily Johnson',
                'title': 'Software Engineer',
                'skills': ['Python', 'JavaScript', 'SQL']
            }
        }

    def get_name_by_email(self, email):
        return self.data.get(email, {}).get('name', 'Unknown')

    def get_title_by_email(self, email):
        return self.data.get(email, {}).get('title', 'Unknown')

    def get_skills_by_email(self, email):
        return self.data.get(email, {}).get('skills', [])

class HtmlWriter:
    @staticmethod
    def write_html(filename, content):
        with open(filename, 'w') as f:
            f.write(content)

class PageCreator:
    _instance = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self.database = Database()
        self.html_writer = HtmlWriter()

    def create_simple_homepage(self, mail_address, html_file_name):
        name = self.database.get_name_by_email(mail_address)
        title = self.database.get_title_by_email(mail_address)
        skills = self.database.get_skills_by_email(mail_address)

        content = f"""
        <html>
        <head>
            <title>{name}'s Homepage</title>
        </head>
        <body>
            <h1>Welcome to {name}'s Homepage</h1>
            <p>Email: {mail_address}</p>
            <p>Title: {title}</p>
            <h2>Skills:</h2>
            <ul>
                {"".join(f"<li>{skill}</li>" for skill in skills)}
            </ul>
        </body>
        </html>
        """

        self.html_writer.write_html(html_file_name, content)
        print(f"'{html_file_name}' is created for {mail_address} ({name})")

if __name__ == '__main__':
    with PyCallGraph(output=test):
        PageCreator().get_instance().create_simple_homepage(mail_address='emily@example.com',
                                                            html_file_name='Homepage.html')