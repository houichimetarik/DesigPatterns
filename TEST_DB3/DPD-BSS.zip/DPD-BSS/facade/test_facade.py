from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "test_facade.json"
test.output_type = 'json'

import unittest

__author__ = 'Bruno'

class Customer:
    def __init__(self, name: str, age: int):
        self.name = name
        self.age = age

class CustomerValidator:
    def validate(self, customer: Customer) -> bool:
        return bool(customer.name) and customer.age > 0

class CustomerRepository:
    def save(self, customer: Customer) -> None:
        print(f"Saving customer: {customer.name}, {customer.age}")

class CustomerFacade:
    def __init__(self):
        self.validator = CustomerValidator()
        self.repository = CustomerRepository()

    def save(self, customer: Customer) -> None:
        if not self.validator.validate(customer):
            raise ValueError("Invalid customer data")
        self.repository.save(customer)

class FacadeTest(unittest.TestCase):
    """
    Facade's Test
    """

    def test_save_customer(self):
        """
        Must save a customer without error
        """
        customer = Customer("Bruno", 21)
        CustomerFacade().save(customer)

    def test_save_customer_error(self):
        """
        Must save a customer with error
        """
        customer = Customer("", 21)
        with self.assertRaises(ValueError):
            CustomerFacade().save(customer)

if __name__ == '__main__':
    with PyCallGraph(output=test):
        unittest.main()