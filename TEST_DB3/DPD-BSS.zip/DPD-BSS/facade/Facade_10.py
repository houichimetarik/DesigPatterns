from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "Facade_10.json"
test.output_type = 'json'

from typing import Union

class PartyHall:
    
    def __init__(self) -> None:
        pass

    def schedule(self) -> bool:
        pass

class RockBand:

    def __init__(self) -> None:
        pass

    def play(self) -> None:
        pass

class Buffet:

    def __init__(self) -> None:
        pass

    def serve(self) -> None:
        pass

class Floriculture:

    def __init__(self) -> None:
        pass

    def deliver_flowers(self) -> None:
        pass

    def arrange_flowers(self) -> None:
        pass

class EventManagement:
    
    def __init__(self) -> None:
        self.party_hall = PartyHall()
        self.rock_band = RockBand()
        self.buffet = Buffet()
        self.floriculture = Floriculture()
    
    def organize(self) -> None:
        
        self.party_hall.schedule()

        self.rock_band.play()

        self.buffet.serve()

        self.floriculture.deliver_flowers()
        self.floriculture.arrange_flowers()

if __name__ == "__main__":
    with PyCallGraph(output=test):
    
        eventManagement = EventManagement()
        eventManagement.organize()