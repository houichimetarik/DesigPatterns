from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "main_5.json"
test.output_type = 'json'

"""
    @author: Ly Tran Vinh
    @contact: lytranvinh.work@gmail.com
    @content: Facade Pattern
"""

class GameEngine:
    def initialize(self):
        print("Game Engine: Initializing...")

    def loadAssets(self):
        print("Game Engine: Loading game assets...")

    def render(self):
        print("Game Engine: Rendering graphics...")

class AudioSystem:
    def initialize(self):
        print("Audio System: Initializing...")

    def loadSounds(self):
        print("Audio System: Loading sound files...")

    def playBackgroundMusic(self):
        print("Audio System: Playing background music...")

class InputHandler:
    def initialize(self):
        print("Input Handler: Initializing...")

    def configureInputs(self):
        print("Input Handler: Configuring input devices...")

class GameFacade:
    def __init__(self):
        self.gameEngine = GameEngine()
        self.audioSystem = AudioSystem()
        self.inputHandler = InputHandler()

    def startGame(self):
        print("Game Facade: Starting the game...")
        self.gameEngine.initialize()
        self.gameEngine.loadAssets()
        self.gameEngine.render()

        self.audioSystem.initialize()
        self.audioSystem.loadSounds()
        self.audioSystem.playBackgroundMusic()

        self.inputHandler.initialize()
        self.inputHandler.configureInputs()

        print("Game Facade: Game started successfully!")

def main():
    """
        Main function
    """
    game = GameFacade()
    game.startGame()
    
if __name__ == '__main__':
    with PyCallGraph(output=test):
        main()