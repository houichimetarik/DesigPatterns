from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "main_2.json"
test.output_type = 'json'

class Employee:
    def __init__(self, name, id):
        self.name = name
        self.id = id

class EmployeeDatabase:
    def get_employee(self, id):
        # Simulating database access
        employees = {
            1: Employee("John Doe", 1),
            2: Employee("Jane Smith", 2),
            3: Employee("Mike Johnson", 3)
        }
        return employees.get(id)

class PayrollSystem:
    def get_salary(self, employee):
        # Simulating payroll calculation
        salaries = {
            1: 50000,
            2: 60000,
            3: 55000
        }
        return salaries.get(employee.id, 0)

class HRSystem:
    def get_job_title(self, employee):
        # Simulating HR system
        titles = {
            1: "Software Engineer",
            2: "Project Manager",
            3: "Data Analyst"
        }
        return titles.get(employee.id, "Unknown")

class EmployeeFacade:
    def __init__(self):
        self.employee_db = EmployeeDatabase()
        self.payroll_system = PayrollSystem()
        self.hr_system = HRSystem()

    def get_employee_details(self):
        # Simulate user input
        employee_id = 2  # Let's say we're looking for employee with ID 2

        employee = self.employee_db.get_employee(employee_id)
        if employee:
            salary = self.payroll_system.get_salary(employee)
            job_title = self.hr_system.get_job_title(employee)

            print(f"Employee Details:")
            print(f"Name: {employee.name}")
            print(f"ID: {employee.id}")
            print(f"Job Title: {job_title}")
            print(f"Salary: ${salary}")
        else:
            print(f"Employee with ID {employee_id} not found.")

if __name__ == "__main__":
    with PyCallGraph(output=test):
        ef = EmployeeFacade()
        ef.get_employee_details()