from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "User.json"
test.output_type = 'json'

#Emulates a user

class TestRunner:
    def runTests(self):
        # Implementation of runTests method
        pass

if __name__ == '__main__':
    with PyCallGraph(output=test):
        testRunnerObj = TestRunner()
        testRunnerObj.runTests()