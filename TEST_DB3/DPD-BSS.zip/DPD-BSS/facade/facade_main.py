from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "facade_main.json"
test.output_type = 'json'


class Vector2D:
    def __init__(self, x: float, y: float):
        self.x = x
        self.y = y

    def __add__(self, other: Vector2D) -> Vector2D:
        return Vector2D(self.x + other.x, self.y + other.y)

    def __repr__(self) -> str:
        return f"({self.x}, {self.y})"

class Vector3D:
    def __init__(self, x: float, y: float, z: float):
        self.x = x
        self.y = y
        self.z = z

    def __add__(self, other: Vector3D) -> Vector3D:
        return Vector3D(self.x + other.x, self.y + other.y, self.z + other.z)

    def __repr__(self) -> str:
        return f"({self.x}, {self.y}, {self.z})"

if __name__ == "__main__":
    with PyCallGraph(output=test):
        print("Operations on: Vector3D")
        v3_1 = Vector3D(1, 2, 3)
        v3_2 = Vector3D(8, 7, 6)
        print(f"{v3_1} + {v3_2} = Vector3D{v3_1 + v3_2}")
        print(f"{v3_1} + {Vector3D(1, 2, 3)} = Vector3D{v3_1 + Vector3D(1, 2, 3)}")
    
        print('_' * 16)
        print("Operations on: Vector2D")
        v2_1 = Vector2D(1, 2)
        v2_2 = Vector2D(8, 7)
        print(f"{v2_1} + {v2_2} = Vector2D{v2_1 + v2_2}")
        print(f"{v2_1} + {Vector2D(1, 2)} = Vector2D{v2_1 + Vector2D(1, 2)}")