from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "exercise_1.json"
test.output_type = 'json'

"""
FaÃ§ade Coding Exercise
"""

class Generator:
    @staticmethod
    def generate_odd(n: int) -> list[list[int]]:
        square = [[0 for _ in range(n)] for _ in range(n)]
        i, j = 0, n // 2
        num = 1
        while num <= n**2:
            square[i][j] = num
            num += 1
            newi, newj = (i - 1) % n, (j + 1) % n
            if square[newi][newj]:
                i = (i + 1) % n
            else:
                i, j = newi, newj
        return square

    @staticmethod
    def generate_even(n: int) -> list[list[int]]:
        square = [[0 for _ in range(n)] for _ in range(n)]
        num = 1
        for i in range(n):
            for j in range(n):
                if (i + j) % 2 == 0:
                    square[i][j] = num
                else:
                    square[n-1-i][n-1-j] = num
                num += 1
        return square

class Splitter:
    @staticmethod
    def split(array: list[list[int]]) -> list[list[int]]:
        n = len(array)
        result = []
        # Rows
        result.extend(array)
        # Columns
        result.extend([[array[i][j] for i in range(n)] for j in range(n)])
        # Diagonals
        result.append([array[i][i] for i in range(n)])
        result.append([array[i][n-1-i] for i in range(n)])
        return result

class Verifier:
    @staticmethod
    def verify(arrays: list[list[int]]) -> bool:
        first = sum(arrays[0])
        return all(sum(arr) == first for arr in arrays[1:])

class MagicSquareGenerator:
    @staticmethod
    def generate(size: int) -> list[list[int]]:
        generator = Generator()
        splitter = Splitter()
        verifier = Verifier()

        if size % 2 == 1:
            square = generator.generate_odd(size)
        else:
            square = generator.generate_even(size)

        split_square = splitter.split(square)
        if verifier.verify(split_square):
            return square
        else:
            raise Exception("Failed to generate a valid magic square")

if __name__ == "__main__":
    with PyCallGraph(output=test):
        size = int(input("Enter the size of the magic square: "))
        magic_square_generator: MagicSquareGenerator = MagicSquareGenerator()
        try:
            magic_square: list[list[int]] = magic_square_generator.generate(size)
            print("Generated Magic Square:")
            for row in magic_square:
                print(row)
        except Exception as e:
            print(f"Error: {e}")