from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "FacadeDemo.json"
test.output_type = 'json'

class BCryptEncryptor:
    def encrypt(self, input_string: str) -> str:
        return f"BCrypt encrypted: {input_string}"

class SCryptEncryptor:
    def encrypt(self, input_string: str) -> str:
        return f"SCrypt encrypted: {input_string}"

class NoOpEncryptor:
    def encrypt(self, input_string: str) -> str:
        return input_string

class EncryptionFacade:
    def __init__(self, scrypt: SCryptEncryptor, bcrypt: BCryptEncryptor, noop: NoOpEncryptor):
        self.scrypt = scrypt
        self.bcrypt = bcrypt
        self.noop = noop

    def encrypt_with_bcrypt(self, input_string: str) -> str:
        return self.bcrypt.encrypt(input_string)

    def encrypt_with_scrypt(self, input_string: str) -> str:
        return self.scrypt.encrypt(input_string)

    def encrypt_without_modification(self, input_string: str) -> str:
        return self.noop.encrypt(input_string)

def main():
    scrypt_encryptor = SCryptEncryptor()
    bcrypt_encryptor = BCryptEncryptor()
    noop_encryptor = NoOpEncryptor()

    encryptorFacade = EncryptionFacade(scrypt_encryptor, bcrypt_encryptor, noop_encryptor)

    print(encryptorFacade.encrypt_with_bcrypt("One"))
    print(encryptorFacade.encrypt_with_scrypt("Two"))
    print(encryptorFacade.encrypt_without_modification("Three"))

if __name__ == '__main__':
    with PyCallGraph(output=test):
        main()