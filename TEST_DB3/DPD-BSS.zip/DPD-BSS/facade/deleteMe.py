from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "deleteMe.json"
test.output_type = 'json'

# Define the Amplifier class inline
class Amplifier:
    def __init__(self, description):
        self.description = description
        self.is_on = False
        self.volume = 0

    def turn_on(self):
        self.is_on = True
        print(f"{self.description} is on")

    def turn_off(self):
        self.is_on = False
        print(f"{self.description} is off")

    def set_volume(self, level):
        self.volume = level
        print(f"{self.description} setting volume to {level}")

    def __str__(self):
        return self.description

if __name__ == '__main__':
    with PyCallGraph(output=test):
        # Create an instance of Amplifier
        amp = Amplifier("Top-O-Line Amplifier")
        
        # Demonstrate some operations
        amp.turn_on()
        amp.set_volume(11)
        amp.turn_off()

        print("Amplifier operations completed.")