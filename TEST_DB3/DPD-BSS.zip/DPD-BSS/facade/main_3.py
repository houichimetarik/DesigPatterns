from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "main_3.json"
test.output_type = 'json'

class Circle:
    def draw(self):
        print("Drawing a circle")

class Square:
    def draw(self):
        print("Drawing a square")

class Triangle:
    def draw(self):
        print("Drawing a triangle")

class ShapeFacade:
    def __init__(self):
        self.circle = Circle()
        self.square = Square()
        self.triangle = Triangle()

    def draw_circle(self):
        self.circle.draw()

    def draw_square(self):
        self.square.draw()

    def draw_triangle(self):
        self.triangle.draw()

def main():
    shape_facade = ShapeFacade()

    shape_facade.draw_circle()
    shape_facade.draw_square()
    shape_facade.draw_triangle()

if __name__ == "__main__":
    with PyCallGraph(output=test):
        main()