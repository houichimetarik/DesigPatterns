from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "Facade_(19).json"
test.output_type = 'json'

class Subsystem1:
    def operation1(self):
        return "Subsystem1: Ready!"

    def operation_n(self):
        return "Subsystem1: Go!"


class Subsystem2:
    def operation1(self):
        return "Subsystem2: Get ready!"

    def operation_z(self):
        return "Subsystem2: Fire!"


class Facade:
    def __init__(self, system1: Subsystem1, system2: Subsystem2):
        self._subsystem1 = system1 or Subsystem1()
        self._subsystem2 = system2 or Subsystem2()

    def operation(self):
        print(self._subsystem1.operation1())
        print(self._subsystem2.operation1())
        print(self._subsystem1.operation_n())
        print(self._subsystem2.operation_z())


if __name__ == "__main__":
    with PyCallGraph(output=test):
        subsystem1 = Subsystem1()
        subsystem2 = Subsystem2()
        facade = Facade(subsystem1, subsystem2)
    
        facade.operation()