from __future__ import annotations
from pycallgraph2 import PyCallGraph
from pycallgraph2.output import GraphvizOutput
test = GraphvizOutput()
test.output_file = "leaf_file_creator.json"
test.output_type = 'json'

import os

class Helper:
    def __init__(self, filename, root_module=None):
        self.filename = filename
        self.root_module = root_module
        self.lines = []

    def write_code_line(self, indent_level, line):
        self.lines.append("    " * indent_level + line)

    def write_empty_line(self):
        self.lines.append("")

    def save(self):
        if self.root_module:
            os.makedirs(self.root_module, exist_ok=True)
            filepath = os.path.join(self.root_module, self.filename)
        else:
            filepath = self.filename

        with open(filepath, 'w') as file:
            file.write("\n".join(self.lines))

class LeafFileCreator:
    def __init__(self, filename, root_module=None):
        self.filename = filename
        self.helper = Helper(filename, root_module)

    def create_leaf_file(self, class_name):
        self.helper.write_code_line(0, f'class {class_name}:')
        self.helper.write_code_line(1, 'def __init__(self):')
        self.helper.write_code_line(2, 'pass')
        self.helper.write_empty_line()
        self.helper.write_code_line(1, 'def operation(self):')
        self.helper.write_code_line(2, f'print("{class_name} operation executed.")')

        self.helper.save()

if __name__ == "__main__":
    with PyCallGraph(output=test):
        leaf_creator = LeafFileCreator("chassis.py", "facade_project")
        leaf_creator.create_leaf_file("Chassis")